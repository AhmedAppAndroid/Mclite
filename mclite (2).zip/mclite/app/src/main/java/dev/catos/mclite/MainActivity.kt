package dev.catos.mclite

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

object Core {
    init { System.loadLibrary("mclite") }
    external fun prepare(version: String, root: String, name: String, uuid: String, token: String, fps: Int): String
    external fun egg(taps: Int, version: String, fps: Int): String
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MaterialTheme(colorScheme = darkColorScheme()) { Home() } }
    }
}

private val Pink = Color(0xFFFF5FA2)

@Composable
fun Home() {
    var version by remember { mutableStateOf("26.1") }
    var fps by remember { mutableIntStateOf(100) }
    var taps by remember { mutableIntStateOf(0) }
    var msg by remember { mutableStateOf("") }
    val scope = rememberCoroutineScope()
    val ctx = LocalContext.current
    val pulse by rememberInfiniteTransition(label = "p")
        .animateFloat(1f, 1.07f, infiniteRepeatable(tween(900), RepeatMode.Reverse), label = "s")

    Column(
        Modifier.fillMaxSize()
            .background(Brush.verticalGradient(listOf(Color(0xFF140A24), Color(0xFF3A1070))))
            .padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(18.dp, Alignment.CenterVertically),
    ) {
        Text("🐱", fontSize = 72.sp, modifier = Modifier.scale(pulse).clickable {
            taps++; msg = Core.egg(taps, version, fps)
        })
        Text("MC Lite", fontSize = 32.sp, color = Color.White)
        Text("Minecraft Java · Rust core", color = Pink)
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            listOf("26.1", "26.3").forEach { v ->
                FilterChip(version == v, { version = v; msg = Core.egg(taps, v, fps) }, { Text(v) })
            }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            listOf(0, 60, 100).forEach { f ->
                FilterChip(fps == f, { fps = f; msg = Core.egg(taps, version, f) },
                    { Text(if (f == 0) "Boost off" else "$f FPS") })
            }
        }
        if (msg.isNotEmpty()) Text(msg, color = Pink)
        Button(
            onClick = {
                scope.launch(Dispatchers.IO) {
                    msg = "Downloading…"
                    // TODO: Microsoft login supplies name/uuid/token.
                    val out = Core.prepare(version, ctx.filesDir.path + "/mc", "", "", "", fps).lines()
                    msg = if (out[0] == "ERR") out.getOrElse(1) { "error" } else "Ready. Needs Java ${out[0]}"
                    // TODO: start the Android JRE with out.drop(1) as its arguments.
                }
            },
            colors = ButtonDefaults.buttonColors(containerColor = Pink),
            shape = RoundedCornerShape(20.dp),
            modifier = Modifier.fillMaxWidth().height(56.dp),
        ) { Text("PLAY", fontSize = 18.sp) }
        Text("by Ahmed", color = Color.White.copy(alpha = 0.5f), fontSize = 12.sp)
    }
}
